"spmTest.binary.version"<-
function() {
return("1.1-2018-05-31")
}
