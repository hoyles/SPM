"spm.binary.version"<-
function() {
return("1.1 (2019-11-13)")
}
