".First.lib"<-
function(library, section)
{
  spm.version()
}
