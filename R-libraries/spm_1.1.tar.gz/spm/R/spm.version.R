"spm.version"<-
function()
{
  cat(paste("spm R package for use with SPM v",spm.binary.version(),"\n",sep=""))
}
